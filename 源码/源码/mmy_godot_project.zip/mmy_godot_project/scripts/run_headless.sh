
#!/bin/bash

# run_headless.sh - Script to run the game in headless mode

# Check if Godot is available
if ! command -v godot &> /dev/null
then
    echo "Godot could not be found, please install it first"
    exit 1
fi

# Run the game in headless mode
echo "Running game in headless mode..."
godot --headless --path ..

# Check the exit code
if [ $? -eq 0 ]; then
    echo "Game ran successfully in headless mode"
else
    echo "Game failed to run in headless mode"
    exit 1
fi

echo "Headless run completed"
