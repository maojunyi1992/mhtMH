
#!/bin/bash

# lint.sh - Script to run code linting

# Check if gdlint is available
if ! command -v gdlint &> /dev/null
then
    echo "gdlint could not be found, please install it first"
    exit 1
fi

# Run gdlint on all GDScript files
echo "Running gdlint on GDScript files..."
gdlint ../autoload/*.gd ../core/*.gd ../core/tables/*.gd ../platform/*.gd ../presentation/*.gd ../tests/unit/*.gd ../tests/integration/*.gd ../tests/performance/*.gd

# Check if clang-tidy is available (for any C++ files if they exist)
if command -v clang-tidy &> /dev/null
then
    echo "Running clang-tidy on C++ files (if any)..."
    # Find all C++ files and run clang-tidy on them
    find .. -name "*.cpp" -o -name "*.h" | xargs -I {} clang-tidy {} -- -I..
else
    echo "clang-tidy not found, skipping C++ linting"
fi

echo "Linting completed"
