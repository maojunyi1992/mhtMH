
#!/bin/bash

# perf_baseline.sh - Script to run performance baseline measurements

# Check if Godot is available
if ! command -v godot &> /dev/null
then
    echo "Godot could not be found, please install it first"
    exit 1
fi

# Run the performance baseline test
echo "Running performance baseline test..."
godot --headless -s ../tests/performance/baseline_test.gd

# Check the exit code
if [ $? -eq 0 ]; then
    echo "Performance baseline test completed successfully"
else
    echo "Performance baseline test failed"
    exit 1
fi

echo "Performance baseline measurement completed"
