
#!/bin/bash

# test.sh - Script to run unit tests

# Check if Godot is available
if ! command -v godot &> /dev/null
then
    echo "Godot could not be found, please install it first"
    exit 1
fi

# Run unit tests
echo "Running unit tests..."
godot --headless -s ../tests/unit/test_runner.gd

# Check the exit code
if [ $? -eq 0 ]; then
    echo "Unit tests completed successfully"
else
    echo "Unit tests failed"
    exit 1
fi

echo "All unit tests passed"
