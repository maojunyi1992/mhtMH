
# Mapping Table - Cocos2d-x to Godot Migration

This document provides a mapping between Cocos2d-x components and their Godot equivalents for the mhtMH project migration.

## Scene Management

| Cocos2d-x Component | Godot Equivalent | Migration Strategy | Notes |
|-------------------|-----------------|-------------------|-------|
| Director/Scene | SceneTree/Scene | Rebuild scene tree | Entry point through autoload singleton |
| Sprite/Layer | Node2D/Control | Node replacement | Z-order managed through z_index |
| Action/Sequence | Tween/AnimationPlayer | Semantic replacement | Timeline interfaces preserved |
| Menu/UI | Control + Theme | Reconstruct flow | StyleBox placeholder |

## Resource Management

| Cocos2d-x Component | Godot Equivalent | Migration Strategy | Notes |
|-------------------|-----------------|-------------------|-------|
| Texture2D/Sprite | Texture/Node2D | Resource loading via provider | MockAssetProvider for testing |
| AudioEngine | AudioStreamPlayer | Interface placeholder | AudioAdapter for mocking |
| Box2D | Physics2D (Area/Body) | Physics replacement | Layer/mask minimal set |

## Core Systems

| Cocos2d-x Component | Godot Equivalent | Migration Strategy | Notes |
|-------------------|-----------------|-------------------|-------|
| CCDirector | SceneTree | Core scene management | Godot's built-in scene tree |
| CCScene | Scene | Scene structure | Godot scenes |
| CCLayer | Node2D/Control | UI layers | Z-order through z_index |
| CCSprite | Sprite2D | Visual elements | Node2D with texture |
| CCMenu/CCMenuItem | Control/Button | UI controls | Godot's UI system |
| CCAction | Tween | Animations | Godot's animation system |

## Input Handling

| Cocos2d-x Component | Godot Equivalent | Migration Strategy | Notes |
|-------------------|-----------------|-------------------|-------|
| CCTouchDispatcher | InputEvent | Input processing | Godot's input system |
| CCKeyboardDispatcher | InputMap | Keyboard input | Godot's input mapping |

## Memory Management

| Cocos2d-x Component | Godot Equivalent | Migration Strategy | Notes |
|-------------------|-----------------|-------------------|-------|
| new/delete | Built-in memory management | RAII/Ownership clarity | Godot handles memory automatically |
| Ref/RefPtr | Reference counting | Automatic reference counting | Built into Godot's Object class |
| AutoreleasePool | Garbage collection | Built-in GC | Godot's garbage collection |

## Data Tables

| Cocos2d-x Component | Godot Equivalent | Migration Strategy | Notes |
|-------------------|-----------------|-------------------|-------|
| TableDataManager | TableDataManager.gd | Rewrite with RAII | Proper lifecycle management |
| TableBase | TableBase.gd | Base class implementation | Virtual ReleaseData method |
| Specific tables (CStageInfo, etc.) | GDScript classes | Direct translation | Maintain data structure |

## Path Handling

| Cocos2d-x Component | Godot Equivalent | Migration Strategy | Notes |
|-------------------|-----------------|-------------------|-------|
| File paths | Resource paths | Path normalization | Cross-platform compatibility |
| CCFileUtils | FileAccess | File operations | Godot's file API |

## Platform Abstraction

| Cocos2d-x Component | Godot Equivalent | Migration Strategy | Notes |
|-------------------|-----------------|-------------------|-------|
| Platform-dependent code | OS singleton | Platform checks | Godot's OS singleton |
| JNI/Objective-C++ bridges | GDNative/GDExtension | Native interfaces | For platform-specific features |

## Key Differences and Considerations

1. **Memory Management**: Godot uses automatic memory management with reference counting, eliminating the need for manual new/delete operations.

2. **Scene System**: Godot's scene system is more flexible than Cocos2d-x's Director/Scene/Layer hierarchy.

3. **Resource Loading**: Godot has a built-in resource system that handles loading and caching automatically.

4. **Input Handling**: Godot uses an event-driven input system with InputMap for action mapping.

5. **Physics**: Godot's 2D physics is based on Box2D but with a different API.

6. **UI System**: Godot's Control nodes provide a comprehensive UI system with themes and styling.

7. **Animation**: Godot's animation system is more powerful and flexible than Cocos2d-x's action system.

8. **Scripting**: Godot uses GDScript (similar to Python) or C# instead of C++ for game logic.

## Adapter Pattern Implementation

To facilitate the migration, we're using adapter patterns:

1. **AssetProvider**: Abstracts resource loading
2. **AudioAdapter**: Handles audio playback
3. **AnimationAdapter**: Manages animations
4. **InputManager**: Processes input events
5. **SceneManager**: Handles scene transitions

These adapters allow us to mock functionality during testing and gradually replace implementations.
