# 更新日志 Changelog

## [0.1.0] - 2025-08-25

### 添加 Added

- 创建完整的项目目录结构 Create complete project directory structure
- 实现客户端基础框架 Implement client base framework
  - Autoload 单例模块 Autoload singleton modules
  - 根场景文件 Root scene files
  - 功能模块入口点 Functional module entry points
- 实现服务器基础框架 Implement server base framework
  - 服务模块 Service modules
  - 协议占位符 Protocol placeholders
  - 数据库和RPC占位符 Database and RPC placeholders
- 创建项目文档 Create project documentation
  - README.md 项目说明 Project description
  - CHANGELOG.md 更新日志 Changelog
  - .gitignore 文件 Git ignore file

### 变更 Changed

- 无 None

### 修复 Fixed

- 无 None

### 移除 Removed

- 无 None
