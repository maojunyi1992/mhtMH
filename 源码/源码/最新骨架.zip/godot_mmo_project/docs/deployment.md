
# 部署指南 (Deployment Guide)

## 目录 (Table of Contents)
1. [概述](#概述)
2. [本地开发环境部署](#本地开发环境部署)
3. [生产环境部署](#生产环境部署)
4. [容器化部署](#容器化部署)
5. [监控和日志配置](#监控和日志配置)
6. [故障恢复](#故障恢复)

## 概述 (Overview)

本文档详细描述了如何在本地开发环境和生产环境中部署Godot MMO项目。项目采用Docker容器化部署，使用Docker Compose编排多个服务，包括游戏服务器、数据库、缓存、监控系统等。

This document provides detailed instructions on how to deploy the Godot MMO project in both local development and production environments. The project uses Docker containerization with Docker Compose to orchestrate multiple services, including game servers, databases, caches, and monitoring systems.

## 本地开发环境部署 (Local Development Deployment)

### 环境要求 (Environment Requirements)
- Docker 20.10+
- Docker Compose 1.29+
- 至少8GB内存
- 至少20GB磁盘空间

### 部署步骤 (Deployment Steps)
1. 克隆项目代码到本地
   ```
   git clone <repository-url>
   cd godot_mmo_project
   ```

2. 构建项目镜像（可选，如果使用预构建镜像可跳过）
   ```
   docker-compose build
   ```

3. 启动所有服务
   ```
   docker-compose up -d
   ```

4. 验证服务状态
   ```
   docker-compose ps
   ```

5. 访问相关服务：
   - 游戏客户端: http://localhost:8080
   - Prometheus监控: http://localhost:9090
   - Grafana可视化: http://localhost:3000
   - Jaeger追踪: http://localhost:16686

### 停止服务 (Stopping Services)
```
docker-compose down
```

## 生产环境部署 (Production Deployment)

### 环境要求 (Environment Requirements)
- Kubernetes 1.20+
- Docker Registry
- 负载均衡器
- 域名解析配置
- SSL证书

### 部署步骤 (Deployment Steps)
1. 构建并推送Docker镜像到私有仓库
   ```
   docker build -t <registry>/godot-mmo-gateway:latest ./server/gateway
   docker push <registry>/godot-mmo-gateway:latest
   
   # 对其他服务重复上述步骤
   ```

2. 修改Kubernetes配置文件，设置正确的镜像地址和环境变量

3. 部署基础设施服务（数据库、缓存等）
   ```
   kubectl apply -f k8s/infrastructure/
   ```

4. 部署游戏服务
   ```
   kubectl apply -f k8s/services/
   ```

5. 部署监控系统
   ```
   kubectl apply -f k8s/monitoring/
   ```

6. 配置Ingress和域名解析

## 容器化部署 (Containerized Deployment)

### Docker镜像构建 (Docker Image Building)
每个服务都有独立的Dockerfile，可以单独构建：

```dockerfile
# server/gateway/Dockerfile
FROM node:16-alpine

WORKDIR /app

COPY package*.json ./
RUN npm install

COPY . .

EXPOSE 8080

CMD ["npm", "start"]
```

### Docker Compose配置 (Docker Compose Configuration)
```yaml
version: '3.8'

services:
  gateway:
    build: ./server/gateway
    ports:
      - "8080:8080"
    environment:
      - NODE_ENV=production
    depends_on:
      - mysql
      - redis

  mysql:
    image: mysql:8.0
    environment:
      MYSQL_ROOT_PASSWORD: password
      MYSQL_DATABASE: mmo_game
    volumes:
      - mysql_data:/var/lib/mysql

  redis:
    image: redis:6-alpine

volumes:
  mysql_data:
```

## 监控和日志配置 (Monitoring and Logging Configuration)

### Prometheus配置 (Prometheus Configuration)
```yaml
# deploy/prometheus/prometheus.yml
global:
  scrape_interval: 15s

scrape_configs:
  - job_name: 'gateway'
    static_configs:
      - targets: ['gateway:8080']
  
  - job_name: 'auth'
    static_configs:
      - targets: ['auth:8080']
```

### Grafana配置 (Grafana Configuration)
```yaml
# deploy/grafana/provisioning/datasources/prometheus.yml
apiVersion: 1

datasources:
  - name: Prometheus
    type: prometheus
    access: proxy
    url: http://prometheus:9090
    isDefault: true
```

### 日志收集 (Log Collection)
使用ELK（Elasticsearch, Logstash, Kibana）栈进行日志收集和分析：
1. 配置应用程序将日志输出到标准输出
2. 使用Fluentd或Filebeat收集容器日志
3. 将日志发送到Elasticsearch
4. 使用Kibana进行日志可视化和分析

## 故障恢复 (Disaster Recovery)

### 数据备份策略 (Data Backup Strategy)
1. MySQL数据库定期备份
   ```
   # 每天凌晨2点备份数据库
   0 2 * * * mysqldump -u root -p mmo_game > /backups/mmo_game_$(date +\%Y\%m\%d).sql
   ```

2. Redis数据持久化配置
   ```redis
   # redis.conf
   save 900 1
   save 300 10
   save 60 10000
   ```

### 服务恢复流程 (Service Recovery Process)
1. 检测服务故障
2. 自动重启失败的容器
3. 如果自动重启失败，发送告警通知
4. 手动介入恢复服务
5. 验证服务恢复正常
6. 记录故障和恢复过程

### 容灾演练 (Disaster Recovery Drill)
定期进行容灾演练，包括：
1. 模拟服务宕机
2. 测试自动恢复机制
3. 验证数据备份完整性
4. 检查监控和告警系统
5. 评估恢复时间目标（RTO）和恢复点目标（RPO）
