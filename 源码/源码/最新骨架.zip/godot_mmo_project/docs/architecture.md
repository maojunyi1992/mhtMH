
# 架构设计文档 (Architecture Design Document)

## 目录 (Table of Contents)
1. [概述](#概述)
2. [客户端架构](#客户端架构)
3. [服务器架构](#服务器架构)
4. [数据流设计](#数据流设计)
5. [技术选型](#技术选型)
6. [安全设计](#安全设计)
7. [可扩展性设计](#可扩展性设计)

## 概述 (Overview)

本项目采用客户端-服务器架构，客户端使用Godot 4.4.1引擎开发，服务器端采用微服务架构设计。整体架构支持大规模并发用户、确定性战斗、经济系统一致性、可观测性、弹性机制和安全防护等企业级MMO游戏核心能力。

This project uses a client-server architecture, with the client developed using the Godot 4.4.1 engine and the server designed with a microservices architecture. The overall architecture supports large-scale concurrent users, deterministic combat, economic system consistency, observability, resilience mechanisms, and security protection for enterprise-level MMO game core capabilities.

## 客户端架构 (Client Architecture)

### 核心模块 (Core Modules)
- **Autoloader**: 系统核心单例模块，包括事件总线、网络管理、配置管理、资源管理等
- **Scenes**: 场景结构，包含登录、主菜单、世界、战斗等核心场景
- **Scripts**: 功能模块脚本，按业务领域划分模块
- **Core**: 核心工具类，如状态机、命令总线、对象池、定时器服务等

### 设计原则 (Design Principles)
1. 模块化设计，降低耦合度
2. 使用事件驱动架构，通过EventBus进行模块间通信
3. MVVM模式实现UI层，分离视图和业务逻辑
4. 资源异步加载和对象池管理，提高性能

## 服务器架构 (Server Architecture)

### 微服务模块 (Microservices Modules)
- **Gateway**: 网关服务，处理客户端连接和消息路由
- **Auth**: 认证服务，处理用户登录和权限验证
- **Session**: 会话服务，管理用户会话状态
- **World**: 世界服务，管理游戏世界和地图
- **Map**: 地图服务，处理地图相关的逻辑
- **Instance**: 副本服务，管理游戏副本实例
- **Battle**: 战斗服务，处理回合制战斗逻辑（权威服务器）
- **Social**: 社交服务，处理聊天、好友、公会等功能
- **Economy**: 经济服务，处理游戏内经济系统和交易
- **Mail**: 邮件服务，处理游戏内邮件系统
- **Ranking**: 排行榜服务，处理排行榜逻辑
- **Admin**: 管理服务，处理GM命令和后台管理
- **ConfigCenter**: 配置中心，管理游戏配置
- **Storage**: 存储服务，与数据库交互

### 设计原则 (Design Principles)
1. 服务无状态设计，便于水平扩展
2. 服务间通过消息队列或RPC通信
3. 数据一致性通过Saga模式和幂等性保证
4. 确定性战斗通过统一随机种子和行动日志实现

## 数据流设计 (Data Flow Design)

### 客户端到服务器 (Client to Server)
1. 客户端通过WebSocket连接网关服务
2. 网关服务验证会话并路由消息到对应服务
3. 各服务处理业务逻辑并返回响应
4. 网关服务将响应转发给客户端

### 服务器内部通信 (Server Internal Communication)
1. 服务间通过内部消息队列或gRPC通信
2. 异步处理非实时性任务
3. 使用分布式事务保证数据一致性

## 技术选型 (Technology Selection)

### 客户端技术 (Client Technologies)
- **游戏引擎**: Godot 4.4.1
- **脚本语言**: GDScript
- **通信协议**: WebSocket
- **序列化**: Protocol Buffers

### 服务器技术 (Server Technologies)
- **编程语言**: TypeScript/Go/Java（可选）
- **通信协议**: WebSocket/gRPC
- **序列化**: Protocol Buffers
- **数据库**: MySQL + Redis
- **消息队列**: RabbitMQ/Kafka（可选）
- **容器化**: Docker
- **编排**: Kubernetes/Docker Compose
- **监控**: Prometheus + Grafana + Jaeger

## 安全设计 (Security Design)

### 客户端安全 (Client Security)
- 消息签名验证，防止篡改
- 参数白名单校验，防止注入攻击
- 客户端完整性校验，防止外挂

### 服务器安全 (Server Security)
- JWT令牌认证，防止未授权访问
- 限流和熔断机制，防止DDoS攻击
- 敏感操作二次验证，防止恶意操作
- 审计日志记录，便于追踪和分析

## 可扩展性设计 (Scalability Design)

### 水平扩展 (Horizontal Scaling)
- 无状态服务设计，便于容器化部署
- 数据分片策略，支持数据库水平扩展
- 负载均衡机制，合理分配请求压力

### 微服务治理 (Microservices Governance)
- 服务注册与发现
- 配置中心统一管理
- 熔断降级机制
- 监控告警系统
