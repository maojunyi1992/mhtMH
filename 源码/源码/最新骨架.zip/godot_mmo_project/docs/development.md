
# 开发规范 (Development Standards)

## 目录 (Table of Contents)
1. [代码风格](#代码风格)
2. [提交规范](#提交规范)
3. [分支策略](#分支策略)
4. [代码审查](#代码审查)
5. [测试规范](#测试规范)
6. [文档规范](#文档规范)

## 代码风格 (Code Style)

### 命名规范 (Naming Conventions)
- **文件名**: 使用英文命名，单词间用下划线分隔，如 `character_manager.gd`
- **类名**: 使用大驼峰命名法，如 `CharacterManager`
- **函数名**: 使用小驼峰命名法，如 `get_character_info`
- **变量名**: 使用小驼峰命名法，如 `playerName`
- **常量名**: 全大写，单词间用下划线分隔，如 `MAX_PLAYERS`

### 注释规范 (Comment Standards)
- 使用中文注释，并在首次出现术语时提供中文解释
- 函数注释应包含功能描述、参数说明和返回值说明
- 类注释应包含类的用途和主要功能
- 复杂逻辑应添加详细注释说明实现思路

### GDScript编码规范 (GDScript Coding Standards)
- 缩进使用4个空格
- 每行代码不超过100个字符
- 合理使用空行分隔代码块
- 使用类型提示提高代码可读性

示例:
```gdscript
# 玩家管理器 (Player Manager)
# 负责管理玩家相关操作，如登录、登出、状态更新等
class_name PlayerManager

# 获取玩家信息
# player_id: 玩家ID
# 返回: 玩家信息字典
func get_player_info(player_id: int) -> Dictionary:
    # 检查玩家是否存在
    if not _players.has(player_id):
        return {}
    
    return _players[player_id]
```

## 提交规范 (Commit Standards)

### 提交信息格式 (Commit Message Format)
```
<type>(<scope>): <subject>

<body>

<footer>
```

### 类型说明 (Type Descriptions)
- **feat**: 新功能
- **fix**: 修复bug
- **docs**: 文档更新
- **style**: 代码格式调整（不影响代码运行）
- **refactor**: 代码重构
- **test**: 测试相关
- **chore**: 构建过程或辅助工具的变动

### 示例 (Examples)
```
feat(battle): 实现确定性战斗引擎

添加了统一随机种子和行动日志功能，确保战斗结果的一致性

Closes #123
```

```
fix(auth): 修复登录令牌过期问题

调整了令牌刷新逻辑，防止并发登录时的令牌冲突

Fixes #456
```

## 分支策略 (Branch Strategy)

### 分支命名规范 (Branch Naming Conventions)
- **main**: 主分支，包含稳定版本
- **develop**: 开发分支，集成新功能
- **feature/功能名**: 功能分支，开发新特性
- **hotfix/问题描述**: 热修复分支，紧急修复bug
- **release/版本号**: 发布分支，准备发布新版本

### 工作流程 (Workflow)
1. 从 `develop` 分支创建功能分支
2. 在功能分支上进行开发
3. 完成功能后提交Pull Request到 `develop`
4. 代码审查通过后合并到 `develop`
5. 定期将 `develop` 合并到 `main`
6. 发布时从 `develop` 创建 `release` 分支

## 代码审查 (Code Review)

### 审查要点 (Review Points)
1. 代码是否符合编码规范
2. 功能实现是否正确完整
3. 是否有潜在的性能问题
4. 是否有安全漏洞
5. 注释是否清晰完整
6. 是否添加了必要的测试

### 审查流程 (Review Process)
1. 开发者提交Pull Request
2. 指定至少一名团队成员进行审查
3. 审查者提出修改建议
4. 开发者根据建议修改代码
5. 审查者确认修改后批准合并

## 测试规范 (Testing Standards)

### 测试类型 (Test Types)
- **单元测试**: 验证单个函数或类的功能
- **集成测试**: 验证多个模块协同工作
- **功能测试**: 验证完整功能流程
- **性能测试**: 验证系统性能指标
- **回归测试**: 验证修复bug后不影响其他功能

### 测试覆盖率 (Test Coverage)
- 核心业务逻辑覆盖率应达到90%以上
- API接口测试覆盖率应达到100%
- 工具类和辅助函数覆盖率应达到80%以上

### 测试工具 (Testing Tools)
- Godot内置测试框架
- 自定义测试场景
- 压力测试脚本

## 文档规范 (Documentation Standards)

### 文档类型 (Document Types)
- **架构文档**: 系统整体设计和模块关系
- **API文档**: 接口定义和使用说明
- **部署文档**: 部署流程和环境配置
- **用户手册**: 用户操作指南
- **开发文档**: 开发流程和规范

### 文档格式 (Document Format)
- 使用Markdown格式编写
- 包含中英文双语内容
- 重要术语首次出现时提供中文解释
- 使用清晰的标题层级
- 包含目录和导航链接

### 更新要求 (Update Requirements)
- 代码变更时同步更新相关文档
- 新功能开发时编写对应文档
- 定期审查和更新文档内容
- 保持文档与代码版本一致
