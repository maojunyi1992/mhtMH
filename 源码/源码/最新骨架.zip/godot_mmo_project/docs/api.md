
# API文档 (API Documentation)

## 目录 (Table of Contents)
1. [概述](#概述)
2. [认证API](#认证api)
3. [角色API](#角色api)
4. [战斗API](#战斗api)
5. [世界API](#世界api)
6. [社交API](#社交api)
7. [经济API](#经济api)

## 概述 (Overview)

本文档详细描述了游戏服务器提供的所有API接口，包括请求格式、响应格式、错误码等信息。所有API均通过WebSocket协议进行通信，使用Protocol Buffers进行数据序列化。

This document provides detailed descriptions of all API interfaces provided by the game server, including request format, response format, and error codes. All APIs communicate via WebSocket protocol and use Protocol Buffers for data serialization.

## 认证API (Authentication API)

### 用户登录 (User Login)
- **请求消息**: `LoginRequest`
- **响应消息**: `LoginResponse`
- **描述**: 用户登录验证
- **请求参数**:
  - `username` (string): 用户名
  - `password` (string): 密码（加密传输）
- **响应参数**:
  - `success` (bool): 登录是否成功
  - `token` (string): 认证令牌
  - `error_code` (int): 错误码（成功时为0）

### 用户注册 (User Registration)
- **请求消息**: `RegisterRequest`
- **响应消息**: `RegisterResponse`
- **描述**: 新用户注册
- **请求参数**:
  - `username` (string): 用户名
  - `password` (string): 密码
  - `email` (string): 邮箱
- **响应参数**:
  - `success` (bool): 注册是否成功
  - `user_id` (int64): 用户ID（成功时返回）
  - `error_code` (int): 错误码（成功时为0）

## 角色API (Character API)

### 创建角色 (Create Character)
- **请求消息**: `CreateCharacterRequest`
- **响应消息**: `CreateCharacterResponse`
- **描述**: 创建新角色
- **请求参数**:
  - `name` (string): 角色名
  - `class` (string): 职业
  - `gender` (int32): 性别
- **响应参数**:
  - `success` (bool): 创建是否成功
  - `character` (Character): 角色信息（成功时返回）
  - `error_code` (int): 错误码

### 选择角色 (Select Character)
- **请求消息**: `SelectCharacterRequest`
- **响应消息**: `SelectCharacterResponse`
- **描述**: 选择进入游戏的角色
- **请求参数**:
  - `character_id` (int64): 角色ID
- **响应参数**:
  - `success` (bool): 选择是否成功
  - `world_info` (WorldInfo): 世界信息（成功时返回）
  - `error_code` (int): 错误码

### 获取角色列表 (Get Character List)
- **请求消息**: `GetCharacterListRequest`
- **响应消息**: `GetCharacterListResponse`
- **描述**: 获取用户的角色列表
- **请求参数**: 无
- **响应参数**:
  - `characters` (repeated Character): 角色列表
  - `error_code` (int): 错误码

## 战斗API (Battle API)

### 开始战斗 (Start Battle)
- **请求消息**: `StartBattleRequest`
- **响应消息**: `StartBattleResponse`
- **描述**: 开始一场新的战斗
- **请求参数**:
  - `enemy_id` (int64): 敌人ID
- **响应参数**:
  - `success` (bool): 是否成功开始战斗
  - `battle_id` (int64): 战斗ID（成功时返回）
  - `participants` (repeated BattleParticipant): 参战者信息
  - `error_code` (int): 错误码

### 执行战斗行动 (Execute Battle Action)
- **请求消息**: `ExecuteBattleActionRequest`
- **响应消息**: `ExecuteBattleActionResponse`
- **描述**: 执行战斗中的行动
- **请求参数**:
  - `battle_id` (int64): 战斗ID
  - `action` (BattleAction): 战斗行动
- **响应参数**:
  - `success` (bool): 行动是否成功执行
  - `result` (ActionResult): 行动结果
  - `next_turn` (BattleParticipant): 下一个行动者
  - `battle_ended` (bool): 战斗是否结束
  - `error_code` (int): 错误码

### 结束战斗 (End Battle)
- **请求消息**: `EndBattleRequest`
- **响应消息**: `EndBattleResponse`
- **描述**: 结束战斗并获取结果
- **请求参数**:
  - `battle_id` (int64): 战斗ID
- **响应参数**:
  - `success` (bool): 是否成功结束战斗
  - `result` (BattleResult): 战斗结果
  - `rewards` (repeated Reward): 奖励信息
  - `error_code` (int): 错误码

## 世界API (World API)

### 移动角色 (Move Character)
- **请求消息**: `MoveCharacterRequest`
- **响应消息**: `MoveCharacterResponse`
- **描述**: 移动角色到指定位置
- **请求参数**:
  - `x` (float): X坐标
  - `y` (float): Y坐标
  - `z` (float): Z坐标
- **响应参数**:
  - `success` (bool): 移动是否成功
  - `new_position` (Vector3): 新位置
  - `error_code` (int): 错误码

### 传送角色 (Teleport Character)
- **请求消息**: `TeleportRequest`
- **响应消息**: `TeleportResponse`
- **描述**: 传送角色到指定地图
- **请求参数**:
  - `map_id` (int32): 地图ID
  - `x` (float): X坐标
  - `y` (float): Y坐标
- **响应参数**:
  - `success` (bool): 传送是否成功
  - `new_map` (MapInfo): 新地图信息
  - `error_code` (int): 错误码

## 社交API (Social API)

### 发送聊天消息 (Send Chat Message)
- **请求消息**: `SendChatMessageRequest`
- **响应消息**: `SendChatMessageResponse`
- **描述**: 发送聊天消息
- **请求参数**:
  - `channel` (ChatChannel): 聊天频道
  - `message` (string): 消息内容
- **响应参数**:
  - `success` (bool): 消息是否发送成功
  - `error_code` (int): 错误码

### 添加好友 (Add Friend)
- **请求消息**: `AddFriendRequest`
- **响应消息**: `AddFriendResponse`
- **描述**: 添加好友
- **请求参数**:
  - `target_user_id` (int64): 目标用户ID
- **响应参数**:
  - `success` (bool): 添加好友是否成功
  - `error_code` (int): 错误码

### 获取好友列表 (Get Friend List)
- **请求消息**: `GetFriendListRequest`
- **响应消息**: `GetFriendListResponse`
- **描述**: 获取好友列表
- **请求参数**: 无
- **响应参数**:
  - `friends` (repeated FriendInfo): 好友信息列表
  - `error_code` (int): 错误码

## 经济API (Economy API)

### 购买物品 (Purchase Item)
- **请求消息**: `PurchaseItemRequest`
- **响应消息**: `PurchaseItemResponse`
- **描述**: 购买商店物品
- **请求参数**:
  - `item_id` (int32): 物品ID
  - `quantity` (int32): 数量
  - `idempotency_key` (string): 幂等键，防止重复购买
- **响应参数**:
  - `success` (bool): 购买是否成功
  - `transaction_id` (string): 交易ID
  - `new_balance` (int64): 新余额
  - `items_received` (repeated Item): 获得的物品
  - `error_code` (int): 错误码

### 使用物品 (Use Item)
- **请求消息**: `UseItemRequest`
- **响应消息**: `UseItemResponse`
- **描述**: 使用背包中的物品
- **请求参数**:
  - `item_id` (int64): 物品实例ID
- **响应参数**:
  - `success` (bool): 使用是否成功
  - `effects` (repeated ItemEffect): 物品效果
  - `error_code` (int): 错误码

### 获取背包信息 (Get Inventory)
- **请求消息**: `GetInventoryRequest`
- **响应消息**: `GetInventoryResponse`
- **描述**: 获取玩家背包信息
- **请求参数**: 无
- **响应参数**:
  - `items` (repeated InventoryItem): 背包物品列表
  - `error_code` (int): 错误码
