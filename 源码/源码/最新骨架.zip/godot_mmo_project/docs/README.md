
# 项目文档 (Project Documentation)

## 目录 (Table of Contents)
1. [项目概述](#项目概述)
2. [架构设计](#架构设计)
3. [API文档](#api文档)
4. [部署指南](#部署指南)
5. [开发规范](#开发规范)
6. [故障排查](#故障排查)
7. [性能调优](#性能调优)

## 项目概述 (Project Overview)

本项目是一个基于Godot 4.4.1引擎开发的大型回合制MMO游戏，参考了《梦幻西游手游》的设计理念。游戏包含了完整的客户端和服务器端架构，支持多玩家在线、回合制战斗、经济系统、社交功能等核心玩法。

This project is a large-scale turn-based MMO game developed using the Godot 4.4.1 engine, inspired by the design concepts of "Fantasy Westward Journey Mobile". The game features a complete client and server architecture, supporting multiplayer online gameplay, turn-based combat, economic systems, social features, and other core gameplay elements.

## 架构设计 (Architecture Design)

### 客户端架构 (Client Architecture)
- **Autoloader**: 包含核心单例模块，如事件总线(EventBus)、网络管理(Net)、配置管理(Config)等
- **Scenes**: 场景结构，包括登录、世界、战斗等核心场景
- **Scripts**: 功能模块脚本，按业务模块划分
- **Core**: 核心工具类，如状态机(FSM)、命令总线(CommandBus)、对象池(ObjectPool)等

### 服务器架构 (Server Architecture)
- **Gateway**: 网关服务，处理客户端连接和消息转发
- **Auth**: 认证服务，处理用户登录和权限验证
- **Session**: 会话服务，管理用户会话状态
- **World**: 世界服务，管理游戏世界和地图
- **Battle**: 战斗服务，处理回合制战斗逻辑
- **Economy**: 经济服务，处理游戏内经济系统
- **Social**: 社交服务，处理聊天、好友、公会等功能
- **Storage**: 存储服务，与数据库交互

## API文档 (API Documentation)

详细的API文档请参考以下文件：
- [认证API](./api/auth_api.md)
- [角色API](./api/character_api.md)
- [战斗API](./api/battle_api.md)
- [世界API](./api/world_api.md)
- [社交API](./api/social_api.md)
- [经济API](./api/economy_api.md)

## 部署指南 (Deployment Guide)

### 本地开发环境部署 (Local Development Deployment)
1. 安装Docker和Docker Compose
2. 克隆项目代码
3. 运行 `docker-compose up` 启动所有服务
4. 访问 http://localhost:8080 查看应用

### 生产环境部署 (Production Deployment)
1. 构建Docker镜像
2. 配置生产环境变量
3. 使用Kubernetes或Docker Swarm部署服务
4. 配置负载均衡和域名解析

## 开发规范 (Development Standards)

### 代码风格 (Code Style)
- 使用英文命名变量、函数和类
- 注释使用中文，并在首次出现术语时提供中文解释
- 遵循Godot GDScript编码规范

### 提交规范 (Commit Standards)
- 使用语义化提交信息
- 每次提交应包含完整的功能或修复
- 提交前运行测试确保代码质量

### 分支策略 (Branch Strategy)
- `main`: 主分支，包含稳定版本
- `develop`: 开发分支，集成新功能
- `feature/*`: 功能分支，开发新特性
- `hotfix/*`: 热修复分支，紧急修复bug

## 故障排查 (Troubleshooting)

### 常见问题 (Common Issues)
1. **无法连接到服务器**
   - 检查Docker容器是否正常运行
   - 确认网络配置和端口映射
   - 查看服务日志定位问题

2. **战斗不同步**
   - 检查确定性战斗引擎实现
   - 确认随机种子和行动序列一致性
   - 验证网络消息传输完整性

### 解决方案 (Solutions)
- 查看详细日志信息
- 使用监控系统分析性能瓶颈
- 参考架构文档确认实现是否符合设计

## 性能调优 (Performance Optimization)

### 系统优化 (System Optimization)
- 数据库查询优化
- 网络消息压缩
- 资源加载和缓存策略
- 内存管理和垃圾回收优化

### 容量规划 (Capacity Planning)
- 监控系统资源使用情况
- 分析用户行为和并发量
- 制定水平扩展策略
- 定期进行压力测试
