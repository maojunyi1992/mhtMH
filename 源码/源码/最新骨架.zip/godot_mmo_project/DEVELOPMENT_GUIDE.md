# 开发指南 Development Guide

## 项目结构说明 Project Structure Description

### 客户端目录结构 Client Directory Structure
```
/client
  /addons          # 插件目录 Plugins directory
  /assets          # 资源目录 Assets directory
  /autoloader      # 自动加载单例目录 Autoload singleton directory
  /scenes          # 场景目录 Scenes directory
  /scripts         # 脚本目录 Scripts directory
  /config          # 配置文件目录 Configuration files directory
  /tests           # 测试目录 Tests directory
```

### 服务器目录结构 Server Directory Structure
```
/server
  /gateway         # 网关服务 Gateway service
  /auth            # 认证服务 Authentication service
  /session         # 会话服务 Session service
  /world           # 世界服务 World service
  /map             # 地图服务 Map service
  /instance        # 副本服务 Instance service
  /battle          # 战斗服务 Battle service
  /social          # 社交服务 Social service
  /economy         # 经济服务 Economy service
  /admin           # 管理服务 Admin service
  /common          # 公共模块 Common modules
  /storage         # 存储模块 Storage modules
  /protocols       # 协议定义 Protocols definition
  /database        # 数据库占位符 Database placeholder
  /rpc             # RPC占位符 RPC placeholder
  /tests           # 测试目录 Tests directory
```

## 开发规范 Development Standards

### 命名规范 Naming Conventions
- 文件名使用英文小写，单词间用下划线分隔 File names use lowercase English, with words separated by underscores
- 类名使用大驼峰命名法 Class names use UpperCamelCase
- 变量名和函数名使用小驼峰命名法 Variable and function names use lowerCamelCase
- 常量名使用全大写，单词间用下划线分隔 Constant names use ALL_CAPS, with words separated by underscores

### 注释规范 Comment Standards
- 所有公共类和函数必须有注释 All public classes and functions must have comments
- 注释采用中英文双语，术语首次出现时附中文解释 Comments are bilingual (Chinese and English), with Chinese explanations for terms when first appearing
- 注释应说明函数用途、参数含义和返回值含义 Comments should explain function purpose, parameter meanings, and return value meanings

### 代码结构规范 Code Structure Standards
- 客户端使用 MVVM 架构模式 Client uses MVVM architectural pattern
- 服务器采用微服务架构 Server uses microservice architecture
- 每个模块包含 data、manager、ui 三个子目录 Each module contains data, manager, and ui subdirectories
- 使用 EventBus 进行模块间通信 Use EventBus for inter-module communication

## Git 工作流 Git Workflow

### 分支策略 Branch Strategy
- `main` - 主分支，包含生产环境代码 Main branch, contains production code
- `develop` - 开发分支，日常开发在此分支进行 Development branch, daily development occurs here
- `feature/*` - 功能分支，用于开发新功能 Feature branches, used for developing new features
- `hotfix/*` - 热修复分支，用于紧急修复生产环境问题 Hotfix branches, used for urgent fixes to production issues

### 提交信息规范 Commit Message Standards
- 使用英文编写提交信息 Write commit messages in English
- 提交信息应简洁明了，说明更改内容 Commit messages should be concise and clear, explaining the changes
- 使用以下前缀标识提交类型 Use the following prefixes to identify commit types:
  - `feat:` 新功能添加 Feature addition
  - `fix:` 问题修复 Bug fix
  - `docs:` 文档更新 Documentation update
  - `style:` 代码格式调整 Code style adjustment
  - `refactor:` 代码重构 Code refactoring
  - `test:` 测试相关 Test related
  - `chore:` 构建过程或辅助工具的变动 Build process or auxiliary tool changes

## 构建和部署 Build and Deployment

### 客户端构建 Client Build
```
# Windows 构建
godot --export "Windows Desktop" ../build/client/windows/godot_mmo.exe

# Android 构建
godot --export "Android" ../build/client/android/godot_mmo.apk
```

### 服务器部署 Server Deployment
```
# 启动服务器
godot server/main.gd
```

## 测试策略 Testing Strategy

### 单元测试 Unit Testing
- 客户端单元测试使用 GDScript 内置测试框架 Client unit tests use GDScript built-in testing framework
- 服务器单元测试使用 GDScript 内置测试框架 Server unit tests use GDScript built-in testing framework

### 集成测试 Integration Testing
- 使用自动化测试脚本进行集成测试 Use automated test scripts for integration testing
- 测试客户端与服务器的交互 Test client-server interaction

## 性能优化 Performance Optimization

### 客户端优化 Client Optimization
- 使用对象池管理频繁创建和销毁的对象 Use object pools to manage frequently created and destroyed objects
- 合理使用场景切换和资源加载 Use scene transitions and resource loading appropriately
- 优化渲染性能，减少 Draw Call Optimize rendering performance, reduce Draw Calls

### 服务器优化 Server Optimization
- 使用异步处理提高并发性能 Use asynchronous processing to improve concurrent performance
- 合理设计数据库索引 Optimize database indexes appropriately
- 使用缓存减少重复计算 Use caching to reduce redundant calculations
