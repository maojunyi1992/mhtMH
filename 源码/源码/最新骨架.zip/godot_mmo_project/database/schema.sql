-- schema.sql
-- MMO游戏数据库Schema定义文件
-- 包含所有业务表结构、索引、约束和初始数据

-- 用户账户表
-- 存储用户基本信息和认证数据
CREATE TABLE IF NOT EXISTS accounts (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '账户ID',
    username VARCHAR(50) NOT NULL UNIQUE COMMENT '用户名',
    email VARCHAR(100) NOT NULL UNIQUE COMMENT '邮箱',
    password_hash VARCHAR(255) NOT NULL COMMENT '密码哈希值',
    salt VARCHAR(50) NOT NULL COMMENT '密码盐值',
    status TINYINT DEFAULT 1 COMMENT '账户状态：1-正常，2-冻结，3-注销',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    last_login_at TIMESTAMP NULL COMMENT '最后登录时间',
    login_count INT DEFAULT 0 COMMENT '登录次数',
    
    INDEX idx_username (username),
    INDEX idx_email (email),
    INDEX idx_status (status)
) COMMENT='用户账户表';

-- 角色表
-- 存储玩家角色信息
CREATE TABLE IF NOT EXISTS characters (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '角色ID',
    account_id BIGINT NOT NULL COMMENT '所属账户ID',
    name VARCHAR(50) NOT NULL UNIQUE COMMENT '角色名称',
    level INT DEFAULT 1 COMMENT '角色等级',
    exp BIGINT DEFAULT 0 COMMENT '经验值',
    gold BIGINT DEFAULT 0 COMMENT '金币数量',
    diamond BIGINT DEFAULT 0 COMMENT '钻石数量',
    hp INT DEFAULT 100 COMMENT '生命值',
    mp INT DEFAULT 50 COMMENT '魔法值',
    attack INT DEFAULT 10 COMMENT '攻击力',
    defense INT DEFAULT 5 COMMENT '防御力',
    speed INT DEFAULT 10 COMMENT '速度',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    last_login_at TIMESTAMP NULL COMMENT '最后登录时间',
    status TINYINT DEFAULT 1 COMMENT '角色状态：1-正常，2-冻结，3-删除',
    
    FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE CASCADE,
    INDEX idx_account_id (account_id),
    INDEX idx_name (name),
    INDEX idx_level (level),
    INDEX idx_status (status)
) COMMENT='角色表';

-- 物品表
-- 存储游戏中所有物品的定义
CREATE TABLE IF NOT EXISTS items (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '物品ID',
    name VARCHAR(100) NOT NULL COMMENT '物品名称',
    description TEXT COMMENT '物品描述',
    type VARCHAR(50) NOT NULL COMMENT '物品类型：装备、消耗品、任务物品等',
    rarity TINYINT DEFAULT 1 COMMENT '稀有度：1-普通，2-稀有，3-史诗，4-传说',
    price BIGINT DEFAULT 0 COMMENT '出售价格',
    max_stack INT DEFAULT 1 COMMENT '最大堆叠数量',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    
    INDEX idx_type (type),
    INDEX idx_rarity (rarity)
) COMMENT='物品表';

-- 角色物品表
-- 存储角色拥有的物品
CREATE TABLE IF NOT EXISTS character_items (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '记录ID',
    character_id BIGINT NOT NULL COMMENT '角色ID',
    item_id BIGINT NOT NULL COMMENT '物品ID',
    quantity INT NOT NULL DEFAULT 1 COMMENT '物品数量',
    equipped BOOLEAN DEFAULT FALSE COMMENT '是否已装备',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '获得时间',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    
    FOREIGN KEY (character_id) REFERENCES characters(id) ON DELETE CASCADE,
    FOREIGN KEY (item_id) REFERENCES items(id) ON DELETE CASCADE,
    INDEX idx_character_id (character_id),
    INDEX idx_item_id (item_id),
    UNIQUE KEY uk_character_item (character_id, item_id)
) COMMENT='角色物品表';

-- 装备属性表
-- 存储装备的属性加成
CREATE TABLE IF NOT EXISTS equipment_attributes (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '属性ID',
    item_id BIGINT NOT NULL COMMENT '物品ID',
    attribute_name VARCHAR(50) NOT NULL COMMENT '属性名称',
    value INT NOT NULL COMMENT '属性值',
    
    FOREIGN KEY (item_id) REFERENCES items(id) ON DELETE CASCADE,
    INDEX idx_item_id (item_id)
) COMMENT='装备属性表';

-- 战斗回放表
-- 存储战斗回放数据
CREATE TABLE IF NOT EXISTS battle_replays (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '回放ID',
    battle_id VARCHAR(100) NOT NULL UNIQUE COMMENT '战斗ID',
    character_id BIGINT NOT NULL COMMENT '参与角色ID',
    replay_data LONGTEXT NOT NULL COMMENT '回放数据（JSON格式）',
    result_hash VARCHAR(64) NOT NULL COMMENT '结果哈希值',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    
    FOREIGN KEY (character_id) REFERENCES characters(id) ON DELETE CASCADE,
    INDEX idx_character_id (character_id),
    INDEX idx_battle_id (battle_id),
    INDEX idx_created_at (created_at)
) COMMENT='战斗回放表';

-- 交易订单表
-- 存储经济系统中的交易订单
CREATE TABLE IF NOT EXISTS trade_orders (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '订单ID',
    order_id VARCHAR(100) NOT NULL UNIQUE COMMENT '订单唯一标识',
    character_id BIGINT NOT NULL COMMENT '角色ID',
    item_id BIGINT NOT NULL COMMENT '物品ID',
    quantity INT NOT NULL COMMENT '数量',
    currency_type VARCHAR(20) NOT NULL COMMENT '货币类型',
    price BIGINT NOT NULL COMMENT '单价',
    order_type TINYINT NOT NULL COMMENT '订单类型：1-购买，2-出售',
    status TINYINT DEFAULT 1 COMMENT '订单状态：1-待处理，2-已完成，3-已取消',
    idempotency_key VARCHAR(100) NOT NULL COMMENT '幂等键',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    
    FOREIGN KEY (character_id) REFERENCES characters(id) ON DELETE CASCADE,
    FOREIGN KEY (item_id) REFERENCES items(id) ON DELETE CASCADE,
    INDEX idx_character_id (character_id),
    INDEX idx_item_id (item_id),
    INDEX idx_order_type (order_type),
    INDEX idx_status (status),
    INDEX idx_idempotency_key (idempotency_key),
    INDEX idx_created_at (created_at)
) COMMENT='交易订单表';

-- 好友关系表
-- 存储玩家之间的好友关系
CREATE TABLE IF NOT EXISTS friendships (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '关系ID',
    player_id BIGINT NOT NULL COMMENT '玩家ID',
    friend_id BIGINT NOT NULL COMMENT '好友ID',
    status TINYINT DEFAULT 1 COMMENT '关系状态：1-已确认，2-待确认，3-已拒绝',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    
    FOREIGN KEY (player_id) REFERENCES characters(id) ON DELETE CASCADE,
    FOREIGN KEY (friend_id) REFERENCES characters(id) ON DELETE CASCADE,
    UNIQUE KEY uk_player_friend (player_id, friend_id),
    INDEX idx_player_id (player_id),
    INDEX idx_friend_id (friend_id),
    INDEX idx_status (status)
) COMMENT='好友关系表';

-- 帮派表
-- 存储帮派信息
CREATE TABLE IF NOT EXISTS guilds (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '帮派ID',
    name VARCHAR(50) NOT NULL UNIQUE COMMENT '帮派名称',
    description TEXT COMMENT '帮派描述',
    leader_id BIGINT NOT NULL COMMENT '帮主ID',
    level INT DEFAULT 1 COMMENT '帮派等级',
    member_count INT DEFAULT 1 COMMENT '成员数量',
    max_members INT DEFAULT 50 COMMENT '最大成员数',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    
    FOREIGN KEY (leader_id) REFERENCES characters(id) ON DELETE CASCADE,
    INDEX idx_name (name),
    INDEX idx_leader_id (leader_id)
) COMMENT='帮派表';

-- 帮派成员表
-- 存储帮派成员信息
CREATE TABLE IF NOT EXISTS guild_members (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '成员ID',
    guild_id BIGINT NOT NULL COMMENT '帮派ID',
    character_id BIGINT NOT NULL COMMENT '角色ID',
    role VARCHAR(20) DEFAULT 'member' COMMENT '成员角色：leader-帮主，officer-官员，member-成员',
    joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '加入时间',
    contribution INT DEFAULT 0 COMMENT '贡献值',
    
    FOREIGN KEY (guild_id) REFERENCES guilds(id) ON DELETE CASCADE,
    FOREIGN KEY (character_id) REFERENCES characters(id) ON DELETE CASCADE,
    UNIQUE KEY uk_guild_character (guild_id, character_id),
    INDEX idx_guild_id (guild_id),
    INDEX idx_character_id (character_id)
) COMMENT='帮派成员表';

-- 邮件表
-- 存储游戏内邮件
CREATE TABLE IF NOT EXISTS mails (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '邮件ID',
    sender_id BIGINT NOT NULL COMMENT '发送者ID',
    receiver_id BIGINT NOT NULL COMMENT '接收者ID',
    subject VARCHAR(100) NOT NULL COMMENT '邮件主题',
    content TEXT NOT NULL COMMENT '邮件内容',
    status TINYINT DEFAULT 1 COMMENT '邮件状态：1-未读，2-已读，3-已删除',
    has_attachment BOOLEAN DEFAULT FALSE COMMENT '是否有附件',
    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '发送时间',
    expired_at TIMESTAMP NULL COMMENT '过期时间',
    
    FOREIGN KEY (sender_id) REFERENCES characters(id) ON DELETE CASCADE,
    FOREIGN KEY (receiver_id) REFERENCES characters(id) ON DELETE CASCADE,
    INDEX idx_receiver_id (receiver_id),
    INDEX idx_status (status),
    INDEX idx_sent_at (sent_at)
) COMMENT='邮件表';

-- 邮件附件表
-- 存储邮件附件信息
CREATE TABLE IF NOT EXISTS mail_attachments (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '附件ID',
    mail_id BIGINT NOT NULL COMMENT '邮件ID',
    item_id BIGINT NOT NULL COMMENT '物品ID',
    quantity INT NOT NULL COMMENT '数量',
    
    FOREIGN KEY (mail_id) REFERENCES mails(id) ON DELETE CASCADE,
    FOREIGN KEY (item_id) REFERENCES items(id) ON DELETE CASCADE,
    INDEX idx_mail_id (mail_id)
) COMMENT='邮件附件表';

-- 排行榜表
-- 存储排行榜数据
CREATE TABLE IF NOT EXISTS rankings (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '排行ID',
    ranking_type VARCHAR(50) NOT NULL COMMENT '排行类型：level-等级排行，wealth-财富排行等',
    character_id BIGINT NOT NULL COMMENT '角色ID',
    rank_value BIGINT NOT NULL COMMENT '排行值',
    rank_position INT NOT NULL COMMENT '排名位置',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    
    FOREIGN KEY (character_id) REFERENCES characters(id) ON DELETE CASCADE,
    UNIQUE KEY uk_ranking_character (ranking_type, character_id),
    INDEX idx_ranking_type_position (ranking_type, rank_position),
    INDEX idx_character_id (character_id)
) COMMENT='排行榜表';

-- 任务表
-- 存储游戏中任务定义
CREATE TABLE IF NOT EXISTS quests (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '任务ID',
    name VARCHAR(100) NOT NULL COMMENT '任务名称',
    description TEXT COMMENT '任务描述',
    type VARCHAR(50) NOT NULL COMMENT '任务类型：主线、支线、日常等',
    level_requirement INT NOT NULL COMMENT '等级要求',
    reward_exp BIGINT DEFAULT 0 COMMENT '奖励经验值',
    reward_gold BIGINT DEFAULT 0 COMMENT '奖励金币',
    reward_items JSON COMMENT '奖励物品（JSON格式）',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    
    INDEX idx_type (type),
    INDEX idx_level_requirement (level_requirement)
) COMMENT='任务表';

-- 角色任务进度表
-- 存储角色任务进度
CREATE TABLE IF NOT EXISTS character_quests (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '进度ID',
    character_id BIGINT NOT NULL COMMENT '角色ID',
    quest_id BIGINT NOT NULL COMMENT '任务ID',
    status TINYINT DEFAULT 1 COMMENT '任务状态：1-未接取，2-进行中，3-已完成',
    progress_data JSON COMMENT '进度数据（JSON格式）',
    accepted_at TIMESTAMP NULL COMMENT '接取时间',
    completed_at TIMESTAMP NULL COMMENT '完成时间',
    
    FOREIGN KEY (character_id) REFERENCES characters(id) ON DELETE CASCADE,
    FOREIGN KEY (quest_id) REFERENCES quests(id) ON DELETE CASCADE,
    UNIQUE KEY uk_character_quest (character_id, quest_id),
    INDEX idx_character_id (character_id),
    INDEX idx_quest_id (quest_id),
    INDEX idx_status (status)
) COMMENT='角色任务进度表';

-- 聊天记录表
-- 存储聊天消息记录
CREATE TABLE IF NOT EXISTS chat_messages (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '消息ID',
    channel VARCHAR(20) NOT NULL COMMENT '频道：world-世界，guild-帮派，private-私聊等',
    sender_id BIGINT NOT NULL COMMENT '发送者ID',
    receiver_id BIGINT NULL COMMENT '接收者ID（私聊时使用）',
    content TEXT NOT NULL COMMENT '消息内容',
    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '发送时间',
    
    FOREIGN KEY (sender_id) REFERENCES characters(id) ON DELETE CASCADE,
    INDEX idx_channel (channel),
    INDEX idx_sender_id (sender_id),
    INDEX idx_receiver_id (receiver_id),
    INDEX idx_sent_at (sent_at)
) COMMENT='聊天记录表';

-- 游戏配置表
-- 存储游戏配置参数
CREATE TABLE IF NOT EXISTS game_configs (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '配置ID',
    config_key VARCHAR(100) NOT NULL UNIQUE COMMENT '配置键',
    config_value TEXT NOT NULL COMMENT '配置值',
    description VARCHAR(255) COMMENT '配置描述',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    
    INDEX idx_config_key (config_key)
) COMMENT='游戏配置表';

-- 系统日志表
-- 存储系统操作日志
CREATE TABLE IF NOT EXISTS system_logs (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '日志ID',
    log_level VARCHAR(10) NOT NULL COMMENT '日志级别：INFO, WARN, ERROR',
    module VARCHAR(50) NOT NULL COMMENT '模块名称',
    message TEXT NOT NULL COMMENT '日志消息',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    
    INDEX idx_log_level (log_level),
    INDEX idx_module (module),
    INDEX idx_created_at (created_at)
) COMMENT='系统日志表';

-- 创建索引和约束的补充语句
-- 为角色表添加更多索引以优化查询性能
ALTER TABLE characters ADD INDEX idx_account_status (account_id, status);
ALTER TABLE characters ADD INDEX idx_level_status (level, status);

-- 为物品表添加更多索引
ALTER TABLE items ADD INDEX idx_name_type (name, type);

-- 为交易订单表添加复合索引
ALTER TABLE trade_orders ADD INDEX idx_character_status (character_id, status);
ALTER TABLE trade_orders ADD INDEX idx_item_status (item_id, status);

-- 为排行榜表添加更多索引
ALTER TABLE rankings ADD INDEX idx_ranking_value (ranking_type, rank_value DESC);

-- 插入初始数据
-- 插入一些基础物品数据
INSERT IGNORE INTO items (id, name, description, type, rarity, price, max_stack) VALUES
(1, '新手剑', '新人玩家的初始武器', 'weapon', 1, 10, 1),
(2, '新手盾', '新人玩家的初始防具', 'armor', 1, 10, 1),
(3, '生命药水', '恢复50点生命值', 'consumable', 1, 5, 20),
(4, '魔法药水', '恢复30点魔法值', 'consumable', 1, 5, 20),
(5, '金币', '游戏中的通用货币', 'currency', 1, 1, 999999),
(6, '钻石', '游戏中的高级货币', 'currency', 4, 100, 999999);

-- 插入一些基础任务数据
INSERT IGNORE INTO quests (id, name, description, type, level_requirement, reward_exp, reward_gold) VALUES
(1, '新手指引', '完成新手教程', 'main', 1, 100, 50),
(2, '第一个任务', '与村庄长老对话', 'main', 1, 200, 100),
(3, '收集材料', '收集5个草药', 'side', 1, 150, 75);

-- 插入一些基础配置数据
INSERT IGNORE INTO game_configs (config_key, config_value, description) VALUES
('game_name', '梦幻西游MMO', '游戏名称'),
('max_level', '100', '最高等级'),
('exp_formula', '100*level^2', '经验计算公式'),
('default_gold', '100', '新角色默认金币'),
('default_diamond', '10', '新角色默认钻石');
