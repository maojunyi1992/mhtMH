# Redis键空间设计规范

## 1. 概述
本文档定义了MMO游戏项目中Redis的键空间结构、命名规范和数据存储策略，确保缓存系统的高效性、可维护性和可扩展性。

## 2. 命名规范
所有Redis键遵循以下命名规范：
```
{项目名}:{环境}:{模块}:{子模块}:{标识符}
```

- 项目名: `mmogame`
- 环境: `dev`/`test`/`prod`
- 模块: `auth`/`user`/`world`/`battle`/`social`/`economy`等
- 子模块: 根据具体业务划分
- 标识符: 具体的数据标识

## 3. 用户会话管理

### 3.1 用户会话信息
```
键名: mmogame:prod:auth:session:{session_id}
类型: STRING
内容: JSON格式的会话信息
过期时间: 2小时
描述: 存储用户会话信息，包括用户ID、登录时间、权限等
```

### 3.2 用户在线状态
```
键名: mmogame:prod:user:online:{user_id}
类型: STRING
内容: 在线状态标识
过期时间: 2小时（通过心跳更新）
描述: 记录用户在线状态，用于快速查询用户是否在线
```

### 3.3 用户会话映射
```
键名: mmogame:prod:user:sessions:{user_id}
类型: SET
内容: 用户的所有会话ID集合
过期时间: 2小时
描述: 记录一个用户的所有活跃会话，用于会话管理和踢下线功能
```

## 4. 游戏世界数据

### 4.1 玩家位置信息
```
键名: mmogame:prod:world:position:{map_id}:{user_id}
类型: HASH
内容: 
  - x: X坐标
  - y: Y坐标
  - z: Z坐标
  - timestamp: 更新时间戳
过期时间: 1小时
描述: 存储玩家在游戏世界中的实时位置
```

### 4.2 地图玩家列表
```
键名: mmogame:prod:world:map_players:{map_id}
类型: SET
内容: 当前地图中的所有玩家ID
过期时间: 动态更新
描述: 记录每个地图中的玩家列表，用于广播消息和视野管理
```

### 4.3 场景对象信息
```
键名: mmogame:prod:world:objects:{map_id}:{object_id}
类型: HASH
内容:
  - type: 对象类型（NPC/怪物/物品等）
  - x: X坐标
  - y: Y坐标
  - z: Z坐标
  - properties: 对象属性（JSON）
过期时间: 根据对象类型确定
描述: 存储地图中动态对象的信息
```

## 5. 战斗系统

### 5.1 战斗房间信息
```
键名: mmogame:prod:battle:room:{battle_id}
类型: HASH
内容:
  - status: 战斗状态（等待/进行中/结束）
  - players: 参与玩家列表（JSON）
  - start_time: 开始时间
  - end_time: 结束时间
过期时间: 战斗结束后24小时
描述: 存储战斗房间的基本信息
```

### 5.2 战斗行动序列
```
键名: mmogame:prod:battle:actions:{battle_id}
类型: LIST
内容: 战斗行动序列（JSON格式）
过期时间: 战斗结束后24小时
描述: 记录战斗中的所有行动，用于回放和确定性验证
```

### 5.3 玩家战斗状态
```
键名: mmogame:prod:battle:player_state:{battle_id}:{user_id}
类型: HASH
内容:
  - hp: 当前生命值
  - mp: 当前魔法值
  - status: 状态（正常/眩晕/沉默等）
  - position: 战斗位置
过期时间: 战斗结束后24小时
描述: 存储玩家在战斗中的实时状态
```

## 6. 社交系统

### 6.1 好友列表
```
键名: mmogame:prod:social:friends:{user_id}
类型: SET
内容: 好友用户ID列表
过期时间: 24小时
描述: 存储用户的好友列表，用于快速查询
```

### 6.2 好友在线状态
```
键名: mmogame:prod:social:friend_status:{user_id}
类型: HASH
内容: 好友ID到在线状态的映射
过期时间: 24小时
描述: 缓存好友的在线状态，减少数据库查询
```

### 6.3 帮派信息
```
键名: mmogame:prod:social:guild:{guild_id}
类型: HASH
内容:
  - name: 帮派名称
  - leader: 帮主ID
  - members: 成员列表（JSON）
  - level: 帮派等级
过期时间: 1小时
描述: 缓存帮派基本信息
```

### 6.4 聊天频道
```
键名: mmogame:prod:social:chat:{channel}:{message_id}
类型: STRING
内容: 聊天消息内容（JSON）
过期时间: 1小时
描述: 缓存聊天消息，用于快速获取历史消息
```

### 6.5 最新聊天消息
```
键名: mmogame:prod:social:chat_recent:{channel}
类型: ZSET
内容: 消息ID和时间戳的有序集合
过期时间: 1小时
描述: 记录频道中最新的聊天消息，便于获取最新消息
```

## 7. 经济系统

### 7.1 玩家钱包信息
```
键名: mmogame:prod:economy:wallet:{user_id}
类型: HASH
内容: 各种货币类型的余额
  - gold: 金币余额
  - diamond: 钻石余额
  - bound_gold: 绑定金币余额
过期时间: 30分钟
描述: 缓存玩家的钱包信息，加速交易处理
```

### 7.2 玩家背包信息
```
键名: mmogame:prod:economy:inventory:{user_id}
类型: HASH
内容: 物品ID到数量的映射
过期时间: 30分钟
描述: 缓存玩家的背包信息
```

### 7.3 交易订单
```
键名: mmogame:prod:economy:order:{order_id}
类型: STRING
内容: 订单信息（JSON）
过期时间: 订单完成后24小时
描述: 存储交易订单信息
```

### 7.4 幂等键记录
```
键名: mmogame:prod:economy:idempotency:{idempotency_key}
类型: STRING
内容: 处理结果标识
过期时间: 24小时
描述: 记录幂等键，防止重复处理
```

## 8. 排行榜系统

### 8.1 等级排行榜
```
键名: mmogame:prod:ranking:level
类型: ZSET
内容: 用户ID和等级的有序集合
过期时间: 1小时（定期更新）
描述: 等级排行榜数据
```

### 8.2 财富排行榜
```
键名: mmogame:prod:ranking:wealth
类型: ZSET
内容: 用户ID和财富值的有序集合
过期时间: 1小时（定期更新）
描述: 财富排行榜数据
```

### 8.3 战斗力排行榜
```
键名: mmogame:prod:ranking:power
类型: ZSET
内容: 用户ID和战斗力的有序集合
过期时间: 1小时（定期更新）
描述: 战斗力排行榜数据
```

## 9. 配置和元数据

### 9.1 游戏配置
```
键名: mmogame:prod:config:game
类型: HASH
内容: 游戏配置键值对
过期时间: 24小时
描述: 缓存游戏全局配置
```

### 9.2 物品配置
```
键名: mmogame:prod:config:item:{item_id}
类型: STRING
内容: 物品配置信息（JSON）
过期时间: 24小时
描述: 缓存物品配置数据
```

## 10. 缓存策略

### 10.1 过期策略
- 热数据：1-2小时过期，通过访问更新
- 温数据：6-12小时过期
- 冷数据：24小时过期
- 临时数据：根据业务需要设置，通常几分钟到几小时

### 10.2 淘汰策略
使用`allkeys-lru`淘汰策略，优先淘汰最近最少使用的键。

### 10.3 更新策略
- 读时更新：缓存未命中时从数据库加载并写入缓存
- 写时更新：数据变更时同步更新缓存
- 定时更新：通过定时任务定期刷新缓存数据

## 11. 监控和维护

### 11.1 性能监控
- 监控键的访问频率和命中率
- 监控内存使用情况
- 监控连接数和命令执行情况

### 11.2 数据一致性
- 实现缓存穿透保护（布隆过滤器）
- 实现缓存击穿保护（互斥锁）
- 实现缓存雪崩保护（随机过期时间）

### 11.3 定期维护
- 定期清理过期键
- 定期分析热点数据
- 定期优化键空间结构
