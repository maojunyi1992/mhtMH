#!/bin/bash

# run_load_test.sh
# 性能压测脚本
# 用于模拟不同并发用户数下的系统性能表现

# 设置变量
PROJECT_DIR="/home/admin/workspace/godot_mmo_project"
REPORTS_DIR="$PROJECT_DIR/load_test_reports"
LOAD_TEST_TOOL="k6"  # 使用 k6 进行压测

# 创建报告目录
mkdir -p $REPORTS_DIR

# 检查k6是否安装
if ! command -v k6 &> /dev/null
then
    echo "k6 未安装，请先安装 k6 压测工具"
    exit 1
fi

echo "开始执行性能压测..."

# 100并发用户测试
run_100_concurrent_test() {
    echo "执行100并发用户测试..."
    k6 run --vus 100 --duration 60s \
           --out json=$REPORTS_DIR/load_test_100_concurrent.json \
           $PROJECT_DIR/tests/load_test_100_vus.js
    echo "100并发用户测试完成"
}

# 300并发用户测试
run_300_concurrent_test() {
    echo "执行300并发用户测试..."
    k6 run --vus 300 --duration 60s \
           --out json=$REPORTS_DIR/load_test_300_concurrent.json \
           $PROJECT_DIR/tests/load_test_300_vus.js
    echo "300并发用户测试完成"
}

# 500并发用户测试
run_500_concurrent_test() {
    echo "执行500并发用户测试..."
    k6 run --vus 500 --duration 60s \
           --out json=$REPORTS_DIR/load_test_500_concurrent.json \
           $PROJECT_DIR/tests/load_test_500_vus.js
    echo "500并发用户测试完成"
}

# 生成压测报告
generate_load_test_report() {
    echo "生成压测报告..."
    local report_file="$REPORTS_DIR/load_test_summary_$(date +%Y%m%d_%H%M%S).txt"
    
    echo "========================================" > $report_file
    echo "           性能压测报告" >> $report_file
    echo "========================================" >> $report_file
    echo "测试时间: $(date)" >> $report_file
    echo "测试工具: k6" >> $report_file
    echo "========================================" >> $report_file
    
    # 在实际应用中，这里会解析k6生成的JSON报告并提取关键指标
    echo "压测结果汇总:" >> $report_file
    echo "  100并发测试: 已执行" >> $report_file
    echo "  300并发测试: 已执行" >> $report_file
    echo "  500并发测试: 已执行" >> $report_file
    echo "========================================" >> $report_file
    echo "详细报告请查看各并发测试的JSON文件" >> $report_file
    
    echo "压测报告已生成: $report_file"
    cat $report_file
}

# 主压测流程
main() {
    case $1 in
        "100")
            run_100_concurrent_test
            ;;
        "300")
            run_300_concurrent_test
            ;;
        "500")
            run_500_concurrent_test
            ;;
        "all"|*)
            run_100_concurrent_test
            run_300_concurrent_test
            run_500_concurrent_test
            ;;
    esac
    
    generate_load_test_report
}

# 执行主流程
main $1
