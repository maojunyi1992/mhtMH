#!/bin/bash

# generate_protobuf.sh
# 协议缓冲区代码生成脚本
# 用于将.proto文件编译为各种语言的代码

# 设置变量
PROTO_DIR="../proto"
OUTPUT_DIR="../generated"
PROTOC_PATH="/usr/bin/protoc"  # 根据实际安装路径调整

# 创建输出目录
mkdir -p $OUTPUT_DIR

# 检查protoc是否安装
if ! command -v protoc &> /dev/null
then
    echo "protoc 未安装，请先安装 Protocol Buffers 编译器"
    exit 1
fi

echo "开始生成 Protocol Buffers 代码..."

# 为 Godot GDScript 生成代码
echo "生成 GDScript 代码..."
mkdir -p $OUTPUT_DIR/gdscript
for proto_file in $PROTO_DIR/*.proto; do
    filename=$(basename "$proto_file" .proto)
    echo "处理 $filename.proto..."
    # 注意：需要安装 protoc-gen-gdscript 插件
    $PROTOC_PATH --plugin=protoc-gen-gdscript=/usr/local/bin/protoc-gen-gdscript \
                 --gdscript_out=$OUTPUT_DIR/gdscript \
                 -I=$PROTO_DIR \
                 $proto_file
done

# 为服务端生成代码（以 Go 为例）
echo "生成 Go 代码..."
mkdir -p $OUTPUT_DIR/go
for proto_file in $PROTO_DIR/*.proto; do
    filename=$(basename "$proto_file" .proto)
    echo "处理 $filename.proto..."
    $PROTOC_PATH --go_out=$OUTPUT_DIR/go \
                 --go_opt=paths=source_relative \
                 -I=$PROTO_DIR \
                 $proto_file
done

# 为 TypeScript 客户端生成代码
echo "生成 TypeScript 代码..."
mkdir -p $OUTPUT_DIR/typescript
for proto_file in $PROTO_DIR/*.proto; do
    filename=$(basename "$proto_file" .proto)
    echo "处理 $filename.proto..."
    # 注意：需要安装 protobufjs 或 ts-proto
    $PROTOC_PATH --plugin=./node_modules/.bin/protoc-gen-ts_proto \
                 --ts_proto_out=$OUTPUT_DIR/typescript \
                 -I=$PROTO_DIR \
                 $proto_file
done

echo "Protocol Buffers 代码生成完成！"
echo "生成的文件位于: $OUTPUT_DIR"
