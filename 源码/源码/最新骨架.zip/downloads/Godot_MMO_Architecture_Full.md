# Godot 4.4.1 大型回合制 MMO 架构文档（类《梦幻西游手游》）

目标：提供一份**可落地、可扩展、可协作**的客户端 + 服务端整体架构与工程蓝图，指导后续实现与迭代。  
风格：结构清晰、简洁要点；术语**首次出现**均附中文解释。

---

## 1. 范围与假设
- **客户端（Client）**：Godot 4.4.1，面向 Windows/Android 的跨平台交付。
- **服务器（Server）**：权威服务器（Authoritative Server，指服务器为最终判定逻辑的架构），偏微服务化。
- **网络负载**：中等并发、强实时性在**战斗服**（Battle Server，专门处理战斗逻辑的服务器）内保障，非战斗逻辑弱实时。
- **美术与资源**：不在本文详述，留给资源管线与美术规范。

---

## 2. 术语约定（首次解释）
- **Node（节点）**：Godot 中的基础运行单元，可组成树形层级。
- **Scene（场景）**：节点集合的封装与复用单元，.tscn 文件。
- **Autoload（自动加载单例）**：在项目启动时加载的单例脚本，用于全局管理器。
- **Signal（信号/事件）**：Godot 的事件机制，用于解耦模块通信。
- **Resource（资源）**：可序列化数据对象（.tres/.res），如配置、材质、曲线等。
- **PackedScene（打包场景）**：可实例化的场景资源。
- **ECS（实体-组件-系统模式）**：以组件解耦数据与行为的架构思想。
- **RPC（远程过程调用）**：客户端与服务器之间的函数/消息调用方式。
- **DTO（数据传输对象）**：用于网络消息的轻量数据结构。
- **MVVM（模型-视图-视图模型）**：UI 架构模式，分离显示与状态逻辑。
- **CDN（内容分发网络）**：加速资源分发的网络服务。

---

## 3. 总体架构总览
- **客户端**：以**场景/节点**为视图层基础，Autoload 单例承载**配置、事件总线（EventBus）、资源管理（Asset）、网络（Net）、状态（GameState）**等核心管理器；系统模块化（战斗/任务/社交/经济/副本/公会等），UI 采用 MVVM。
- **服务器**：网关（Gateway，统一接入层）统一接入，鉴权（Auth，账号认证）发放令牌，会话（Session，连接维持）维持长连接，世界（World）/地图（Map）/副本（Instance）分片托管，战斗（Battle）权威判定，社交（Social）/经济（Economy）服务解耦；持久化 MySQL（关系型数据库）+ Redis（内存缓存），内部 RPC（例如 gRPC）通信。

---

## 4. 工程目录结构（示例）
### 4.1 客户端（Client）
```
/client
  /addons                    
  /assets                    
  /autoloader                
  /scenes
  /scripts
  /config                    
  /tests                     
```
### 4.2 服务器（Server）
```
/server
  /gateway
  /auth
  /session
  /world
  /map
  /instance
  /battle
  /social
  /economy
  /admin
  /common
  /storage
  /tests
```

---

## 5. 客户端架构
- **根层结构**：AppRoot、UIRoot、WorldRoot、BattleRoot。
- **核心基建**：EventBus、Config、Asset、Net、Save、Logger。
- **UI 框架**：采用 MVVM 模式。
- **功能模块**：账户/角色、角色属性、技能系统、战斗系统、道具装备、任务、副本、经济、社交、邮件、排行榜、活动。

---

## 6. 客户端性能与质量
- 帧预算：UI <4ms、逻辑 <6ms、渲染 <8ms。
- 异步加载与对象池优化。
- 单元测试、集成测试、UI 自动化、回滚与 AB 测试。

---

## 7. 服务器架构
- **服务划分**：Gateway、Auth、Session、World、Map、Instance、Battle、Social、Economy、Mail、Admin、Config Center、Storage。
- **内部通信**：RPC + 消息队列。
- **安全性**：权威判定、参数校验、风控。

---

## 8. 客户端 ⇄ 服务器 协议示例
- 登录：`C2S.Auth.Login` → `S2C.Auth.Token`
- 战斗：`C2S.Battle.Action` → `S2C.Battle.Result`

---

## 9. 数据模型（核心表）
| 领域 | 表 | 字段 |
|------|----|------|
| 账号 | account | uid, ban_flag |
| 角色 | role | role_id, uid, level |
| 物品 | item | item_id, owner_id |
| 交易 | trade_order | order_id, seller, buyer |
| 公会 | guild | guild_id, leader_id |
| 邮件 | mail | mail_id, to_role_id |
| 战斗回放 | battle_replay | replay_id, seed, hash |

---

## 10. 登录与进线流程
1. 客户端提交凭证 → Auth 验证 → 返回令牌。  
2. 客户端连接 Gateway → 建立会话。  
3. 拉取角色列表 → 选择角色 → World 分配地图。  

---

## 11. 副本与匹配流程
1. 发起匹配 → 成功后分配 Instance。  
2. Instance 通知 World → 客户端载入副本场景。  

---

## 12. 回合战斗流程
1. Battle 分配随机种子与行动顺序。  
2. 玩家提交行动 → 服务器结算。  
3. 广播增量帧 → Buff 结算 → 胜负判定。  

---

## 13. 扩展性与活动系统
- 活动由配置中心驱动。  
- 功能解锁基于等级与进度。  
- 多区多服支持跨服战斗。  

---

## 14. 国际化与本地化
- 字符串表管理多语言。  
- 本地化支持断行、单位。  
- 语言包支持热更新。  

---

## 15. 构建与发布
- 分支策略：main/dev/feature/hotfix。  
- CI/CD：静态检查、单元/回放测试。  
- 交付：Windows/Android 包体。  

---

## 16. 性能与监控
- 客户端目标：首包 ≤ 300MB，常驻内存 ≤ 800MB。  
- 服务器目标：单 Battle 实例 ≤ 200 并发战斗。  
- 监控指标：延迟、崩溃率、DAU、留存。  

---

## 17. 风险与对策
- 战斗复杂性：规则脚本化降低成本。  
- 经济系统：闭环回收防止通胀。  
- 网络波动：断线重连 + AI 托管。  
- 热更失败：双版本容错与回滚。  

---
